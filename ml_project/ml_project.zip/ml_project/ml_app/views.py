from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
import joblib

# Create your views here.
def home(request):
    res=render(request,'home.html')
    return res
    def resutl(request):
        #scaler = joblib.load('scalermodel.pkl')
        #model = joblib.load('mlmodel.pkl')
        pass

        

    
